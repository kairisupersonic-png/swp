"""
Variational Auto Trading Bot
==============================
- Login otomatis via SIWE, fallback solve Cloudflare Turnstile via 2captcha
- HTTP client pakai curl_cffi (TLS fingerprint niru Chrome asli)
- Auto-sizing posisi dari saldo Variational
- Farming volume BTC, ETH, SOL, SUI
- Notifikasi & kontrol via Telegram (opsional, lihat settings.py -> TELEGRAM)

Cara pakai:
  1. pip install -r requirements.txt
  2. Isi user_data/private_key.txt dengan private key wallet kamu
  3. (Opsional) Isi user_data/cf_cookies.txt dengan cookie browser, format:
       cf_clearance=xxx
       vr-token=xxx
       cf_bm=xxx
     Kalau file ini kosong/tidak ada, atau cookie-nya basi, bot otomatis
     login SIWE + solve Turnstile (butuh CAPTCHA_API_KEY di settings.py / env)
  4. (Opsional) Isi TELEGRAM_BOT_TOKEN & TELEGRAM_CHAT_ID (env var atau settings.py)
  5. python main.py
"""

import asyncio
import sys
import random
import time
from pathlib import Path
from datetime import datetime, timedelta

from modules.core.logger import setup_logger
from modules.core.variational_client import VariationalClient
from modules.core.constants import CLOUDFLARE_CONFIG
from modules.core.state import BotState
from modules.core.swap_picker import SwapPicker
from modules.helpers.captcha_solver import solve_turnstile

import settings as cfg

log = setup_logger()

TelegramNotifier = None
if getattr(cfg, "TELEGRAM", {}).get("enabled") and cfg.TELEGRAM.get("bot_token") and cfg.TELEGRAM.get("chat_id"):
    try:
        from modules.helpers.telegram_bot import TelegramNotifier as _TN
        TelegramNotifier = _TN
    except ImportError:
        log.warning("python-telegram-bot belum terinstall (pip install -r requirements.txt). Telegram dimatikan.")

# ─── TAMPILAN ─────────────────────────────────────────────────────────────────

def print_summary_box(balance: float, total_pnl: float, total_volume: float):
    lines = [
        "VARIATIONAL BOT",
        f"Saldo  : ${balance:,.2f}",
        f"PnL    : ${total_pnl:+,.2f}",
        f"Volume : ${total_volume:,.2f}",
    ]
    width = max(len(l) for l in lines) + 4
    top = "╔" + "═" * width + "╗"
    bot = "╚" + "═" * width + "╝"
    log.info(top)
    for i, l in enumerate(lines):
        pad = width - len(l)
        left = pad // 2
        right = pad - left
        text = " " * left + l + " " * right
        log.info("║" + text + "║" if i > 0 else "║" + text.center(width) + "║")
    log.info(bot)

# ─── BALANCE SIZING ──────────────────────────────────────────────────────────

def calc_trade_size(balance: float) -> float:
    b      = cfg.BALANCE
    usable = balance * (1.0 - b["reserve_pct"])
    size   = usable * b["usage_pct"] * b.get("leverage", 1)
    size   = max(size, b["min_size_usd"])
    if b["max_size_usd"] is not None:
        size = min(size, b["max_size_usd"])
    return round(size, 2)

# ─── COOKIES (dari file, bukan hardcode di source) ───────────────────────────

def load_cookies_from_file() -> dict:
    """
    Baca user_data/cf_cookies.txt kalau ada. Format per baris: key=value
    Key yang dikenali: cf_clearance, vr-token (atau vr_token), cf_bm (atau __cf_bm)
    File ini sengaja dipisah dari source code supaya gampang di-.gitignore
    dan tidak ketempel ke mana-mana kalau kamu share source code bot-nya.
    """
    path = Path("user_data/cf_cookies.txt")
    result = {"cf_clearance": None, "vr_token": None, "cf_bm": None}
    if not path.exists():
        return result

    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip().lower().replace("-", "_").lstrip("_")
        val = val.strip()
        if not val:
            continue
        if key in ("cf_clearance",):
            result["cf_clearance"] = val
        elif key in ("vr_token", "vrtoken"):
            result["vr_token"] = val
        elif key in ("cf_bm", "cfbm"):
            result["cf_bm"] = val

    return result


async def ensure_authenticated(client: VariationalClient) -> bool:
    """
    Coba pakai cookie manual dulu (kalau ada & masih hidup). Kalau kena
    Cloudflare challenge atau tidak ada cookie sama sekali, fallback ke
    login SIWE resmi + solve Turnstile via 2captcha.
    """
    if client.jwt_token and client.cf_clearance:
        try:
            log.info("Mencoba pakai cookie browser yang tersimpan...")
            balance = await client.get_available_balance()
            log.success(f"Cookie browser masih valid! Saldo: ${balance:,.2f}")
            return True
        except Exception as e:
            if "Cloudflare challenge" in str(e):
                log.warning("Cookie browser basi / kena Cloudflare challenge. Fallback ke login SIWE...")
            else:
                log.warning(f"Cookie browser gagal dipakai ({e}). Fallback ke login SIWE...")

    # ── Fallback: solve Turnstile lalu login SIWE ──
    if not cfg.CAPTCHA.get("enabled") or not cfg.CAPTCHA.get("api_key"):
        log.error(
            "Tidak ada cookie valid dan CAPTCHA_API_KEY belum diisi.\n"
            "  Opsi 1: isi user_data/cf_cookies.txt dengan cookie browser terbaru\n"
            "  Opsi 2: daftar https://2captcha.com, isi API key di settings.py "
            "(CAPTCHA['api_key']) atau env var CAPTCHA_API_KEY"
        )
        return False

    token = await solve_turnstile(
        api_key  = cfg.CAPTCHA["api_key"],
        sitekey  = CLOUDFLARE_CONFIG["turnstile_sitekey"],
        page_url = CLOUDFLARE_CONFIG["page_url"],
    )
    if not token:
        log.error("Gagal solve Turnstile. Coba lagi nanti atau isi cookie manual.")
        return False

    client.turnstile_token = token
    ok = await client.login(referral_code=cfg.REFERRAL_CODE or None)
    if not ok:
        return False

    try:
        balance = await client.get_available_balance()
        log.success(f"Login SIWE berhasil! Saldo: ${balance:,.2f}")
        return True
    except Exception as e:
        log.error(f"Login berhasil tapi gagal cek saldo: {e}")
        return False

async def ensure_authenticated_with_retry(client: VariationalClient, tg=None,
                                          max_attempts: int = 10, wait_sec: int = 60) -> bool:
    """
    Koneksi ke Variational kadang timeout (jaringan/ISP/Cloudflare). Daripada
    langsung mati, coba lagi beberapa kali dengan jeda dulu.
    """
    for attempt in range(1, max_attempts + 1):
        if await ensure_authenticated(client):
            return True
        if attempt == 1 and tg:
            await tg.notify_error(
                f"Gagal konek/login ke Variational. Bot coba lagi otomatis tiap {wait_sec}s "
                f"(maks {max_attempts}x). Cek koneksi internet / VPN kamu."
            )
        if attempt < max_attempts:
            log.warning(f"Auth gagal (percobaan {attempt}/{max_attempts}). Coba lagi dalam {wait_sec}s...")
            await asyncio.sleep(wait_sec)
    return False

# ─── TRADING ─────────────────────────────────────────────────────────────────

def quote_kwargs(kind: str) -> dict:
    """Parameter instrument untuk get_indicative_quote. kind: 'perp' | 'swap'."""
    if kind == "swap":
        sw = cfg.SWAP
        return {"instrument_type": sw.get("instrument_type"),
                "instrument_extra": sw.get("instrument_extra") or None}
    return {}


def swap_underlying(market: str) -> str:
    return cfg.SWAP.get("underlying_map", {}).get(market, market)


async def open_position(client: VariationalClient, market: str, side: str, size_usd: float, tg=None, kind: str = "perp"):
    try:
        api_market = swap_underlying(market) if kind == "swap" else market
        qk = quote_kwargs(kind)
        quote = await client.get_indicative_quote(api_market, 1.0, **qk)
        mark_price = float(quote.get("mark_price", 0))
        if mark_price <= 0:
            log.error(f"Mark price invalid {market}: {mark_price}")
            return None

        qty   = round(size_usd / mark_price, 6)
        quote = await client.get_indicative_quote(api_market, qty, **qk)
        quote_id = quote.get("quote_id")

        if not quote_id:
            log.error(f"Tidak ada quote_id untuk {market}: {quote}")
            return None

        api_side = "buy" if side == "LONG" else "sell"
        await client.accept_quote(
            quote_id       = quote_id,
            side           = api_side,
            max_slippage   = cfg.TRADING["slippage"],
            is_reduce_only = False
        )

        log.success(f"OPEN {side} {market} | qty={qty:.6f} | price=${mark_price:,.4f} | size=${size_usd:,.2f}")
        if tg:
            await tg.notify_open(market, side, mark_price, size_usd)
        return {"market": market, "side": side, "qty": qty, "kind": kind,
                "entry_price": mark_price, "size_usd": size_usd, "opened_at": time.time()}

    except Exception as e:
        log.error(f"Gagal buka {side} {market}: {e}")
        return None


async def close_position(client: VariationalClient, position: dict, tg=None, state: BotState = None, reason: str = "TIME") -> bool:
    market = position["market"]
    side   = position["side"]
    qty    = position["qty"]
    kind   = position.get("kind", "perp")
    try:
        api_market = swap_underlying(market) if kind == "swap" else market
        quote      = await client.get_indicative_quote(api_market, qty, **quote_kwargs(kind))
        quote_id   = quote.get("quote_id")
        mark_price = float(quote.get("mark_price", position["entry_price"]))

        if not quote_id:
            log.error(f"Tidak ada quote_id untuk close {market}")
            return False

        close_side = "sell" if side == "LONG" else "buy"
        await client.accept_quote(
            quote_id       = quote_id,
            side           = close_side,
            max_slippage   = cfg.TRADING["slippage"],
            is_reduce_only = True
        )

        entry     = position["entry_price"]
        hold_time = time.time() - position["opened_at"]
        pnl       = ((mark_price - entry) / entry if side == "LONG"
                     else (entry - mark_price) / entry) * position["size_usd"]

        log.success(f"CLOSE {side} {market} | price=${mark_price:,.4f} | PnL=${pnl:+.2f} | held={hold_time:.0f}s")

        if state:
            state.record_close(pnl, position["size_usd"])
        if tg:
            await tg.notify_close(market, side, mark_price, pnl, hold_time, reason=reason)

        return True

    except Exception as e:
        log.error(f"Gagal tutup {side} {market}: {e}")
        return False


async def get_live_pnl(client: VariationalClient, position: dict) -> dict:
    market, qty, side, entry = position["market"], position["qty"], position["side"], position["entry_price"]
    kind = position.get("kind", "perp")
    api_market = swap_underlying(market) if kind == "swap" else market
    quote = await client.get_indicative_quote(api_market, qty, **quote_kwargs(kind))
    mark_price = float(quote.get("mark_price", entry))
    pnl = ((mark_price - entry) / entry if side == "LONG" else (entry - mark_price) / entry) * position["size_usd"]
    pnl_pct = (pnl / position["size_usd"]) * 100 if position["size_usd"] else 0.0
    return {"market": market, "side": side, "entry": entry, "mark": mark_price, "pnl": pnl, "pnl_pct": pnl_pct}


async def watch_pnl_alert(client: VariationalClient, position: dict, tg, alert_pct: float):
    """Jalan di background selama posisi ditahan; kirim 1x alert kalau floating PnL kena ambang minus."""
    alerted = False
    try:
        while True:
            await asyncio.sleep(5)
            try:
                live = await get_live_pnl(client, position)
            except Exception:
                continue
            if not alerted and live["pnl_pct"] <= -abs(alert_pct):
                alerted = True
                await tg.notify_pnl_alert(live["market"], live["side"], live["pnl_pct"])
    except asyncio.CancelledError:
        pass

# ─── MAIN LOOP ────────────────────────────────────────────────────────────────

async def farming_loop(client: VariationalClient, state: BotState, tg=None):
    balance = await client.get_available_balance()

    if balance <= 0:
        log.error(
            "Saldo Variational = $0!\n"
            "Pastikan sudah deposit USDC di https://omni.variational.io"
        )
        return

    size_usd = calc_trade_size(balance)
    state.balance = balance

    picker = (SwapPicker(cfg.SWAP["must_include"], cfg.SWAP["pool"], cfg.SWAP.get("others_per_round", 2))
              if getattr(cfg, "MODE", "perp") == "swap" else None)

    log.info("=" * 60)
    log.info("🚀 VARIATIONAL AUTO TRADING BOT AKTIF")
    log.info(f"   Wallet   : {client.eth_address}")
    log.info(f"   Saldo    : ${balance:,.2f} USDC")
    log.info(f"   Reserve  : {cfg.BALANCE['reserve_pct']*100:.0f}% (${balance*cfg.BALANCE['reserve_pct']:,.2f})")
    log.info(f"   Per trade: {cfg.BALANCE['usage_pct']*100:.0f}% x{cfg.BALANCE.get('leverage', 1)} = ${size_usd:,.2f}")
    if cfg.BALANCE.get("leverage", 1) > 10:
        log.warning(f"⚠️ Leverage x{cfg.BALANCE['leverage']} tinggi — risiko likuidasi besar. "
                    f"Pastikan leverage di website Variational sama/lebih tinggi.")
    if getattr(cfg, "MODE", "perp") == "swap":
        log.info(f"   Mode     : SWAP acak | {picker.describe()} | hold {cfg.SWAP['hold_seconds']/60:.0f} menit")
    else:
        log.info(f"   Markets  : {', '.join(cfg.TRADING['markets'])}")
    log.info("=" * 60)
    print_summary_box(balance, state.total_pnl, state.total_volume)

    if size_usd < cfg.BALANCE["min_size_usd"]:
        log.error(f"Size ${size_usd:.2f} di bawah minimum ${cfg.BALANCE['min_size_usd']}.")
        return

    cycle        = 0
    sides        = ["LONG", "SHORT"]
    refresh_n    = cfg.BALANCE.get("refresh_every_n_cycles", 5)
    report_secs  = cfg.TELEGRAM.get("report_every_hours", 0) * 3600 if getattr(cfg, "TELEGRAM", None) else 0
    last_report  = time.time()

    while True:
        # ── kontrol dari Telegram ──
        if state.killswitch:
            log.warning("Killswitch aktif. Bot berhenti.")
            if tg:
                await tg.notify("🛑 Killswitch dieksekusi. Bot berhenti.")
            return

        if state.paused:
            await asyncio.sleep(2)
            continue

        if report_secs and (time.time() - last_report) >= report_secs:
            last_report = time.time()
            if tg:
                await tg.notify_report()

        cycle += 1

        if cycle % refresh_n == 1:
            try:
                new_bal = await client.get_available_balance()
                if new_bal > 0:
                    balance  = new_bal
                    size_usd = calc_trade_size(balance)
                    state.balance = balance
                    log.info(f"[BALANCE] ${balance:,.2f} → trade ${size_usd:,.2f}")
                    print_summary_box(balance, state.total_pnl, state.total_volume)
            except Exception as e:
                log.warning(f"Gagal refresh saldo, coba re-auth... ({e})")
                if not await ensure_authenticated_with_retry(client, tg=tg):
                    log.error("Re-auth gagal berkali-kali. Bot berhenti.")
                    if tg:
                        await tg.notify_error("Re-auth gagal. Bot berhenti.")
                    return

        if size_usd < cfg.BALANCE["min_size_usd"]:
            log.warning(f"Saldo tidak cukup (${size_usd:.2f}). Tunggu 60s...")
            await asyncio.sleep(60)
            continue

        swap_mode = getattr(cfg, "MODE", "perp") == "swap"
        kind      = "swap" if swap_mode else "perp"
        if swap_mode:
            sw       = cfg.SWAP
            market   = picker.next()          # acak, XAU wajib tiap ronde, tidak pernah sama 2x berturut
            side     = sides[cycle % 2]       # arah gantian tiap posisi
            jitter   = sw.get("hold_jitter_seconds", 0)
            hold_sec = sw["hold_seconds"] + (random.uniform(-jitter, jitter) if jitter else 0)
            tp_pct   = sw.get("take_profit_pct", 0)
            sl_pct   = sw.get("stop_loss_pct", 0)
        else:
            market   = random.choice(cfg.TRADING["markets"])
            side     = sides[cycle % 2]
            hold_sec = random.uniform(*cfg.DELAYS["hold_time_range"])  # batas waktu MAX
            tp_pct   = cfg.TRADING.get("take_profit_pct", 0)
            sl_pct   = cfg.TRADING.get("stop_loss_pct", 0)
        check_iv = cfg.TRADING.get("pnl_check_interval", 5)

        log.info(f"\n{'─'*55}")
        log.info(f"[CYCLE {cycle}] {kind.upper()} {side} {market} | ${size_usd:,.2f} | Max hold {hold_sec:.0f}s | TP {tp_pct}% / SL {sl_pct}%")
        log.info(f"{'─'*55}")

        position = await open_position(client, market, side, size_usd, tg=tg, kind=kind)

        if position:
            state.position = position

            alert_pct = cfg.TELEGRAM.get("pnl_alert_pct", 0) if getattr(cfg, "TELEGRAM", None) else 0
            watcher = asyncio.create_task(watch_pnl_alert(client, position, tg, alert_pct)) if (tg and alert_pct) else None

            log.info(f"Memantau posisi (TP/SL/max {hold_sec:.0f}s)...")
            waited     = 0.0
            exit_reason = "TIME"
            while waited < hold_sec:
                if state.force_close_requested or state.killswitch:
                    exit_reason = "MANUAL"
                    break

                step = min(check_iv, hold_sec - waited)
                await asyncio.sleep(step)
                waited += step

                try:
                    live = await get_live_pnl(client, position)
                except Exception as e:
                    log.warning(f"Gagal cek live PnL: {e}")
                    continue

                if tp_pct and live["pnl_pct"] >= tp_pct:
                    log.success(f"🎯 Take Profit kena ({live['pnl_pct']:+.2f}%), tutup posisi lebih cepat.")
                    exit_reason = "TP"
                    break
                if sl_pct and live["pnl_pct"] <= -abs(sl_pct):
                    log.warning(f"🛑 Stop Loss kena ({live['pnl_pct']:+.2f}%), tutup posisi.")
                    exit_reason = "SL"
                    break

            if watcher:
                watcher.cancel()

            log.info(f"Alasan tutup: {exit_reason}")
            closed = False
            for attempt in range(1, 6):
                closed = await close_position(client, position, tg=tg, state=state, reason=exit_reason)
                if closed:
                    break
                log.warning(f"Gagal tutup posisi (percobaan {attempt}/5). Coba lagi dalam 15s...")
                await asyncio.sleep(15)
            if not closed:
                log.error("POSISI MASIH TERBUKA & gagal ditutup otomatis! Cek manual di omni.variational.io")
                if tg:
                    await tg.notify_error(
                        f"POSISI {position['side']} {position['market']} MASIH TERBUKA dan gagal ditutup "
                        f"otomatis. Tutup manual di omni.variational.io!"
                    )
                return
            state.position = None
            state.force_close_requested = False
            log.info(f"[STATS] Volume session: ${state.total_volume:,.2f} | PnL session: ${state.total_pnl:+,.2f}")
        else:
            if picker:
                picker.requeue(market)   # mungkin market lagi tutup; coba market lain dulu
            log.warning(f"Order gagal, retry dalam {cfg.DELAYS['on_error']}s...")
            await asyncio.sleep(cfg.DELAYS["on_error"])
            continue

        cooldown = random.uniform(*(cfg.SWAP["cooldown_seconds"] if swap_mode else cfg.DELAYS["between_cycles"]))
        log.info(f"Cooldown {cooldown:.0f}s...\n")
        await asyncio.sleep(cooldown)

# ─── PILIH MODE ──────────────────────────────────────────────────────────────

def choose_mode() -> str:
    """
    Menu pilihan saat bot dijalankan. Hasilnya disimpan ke cfg.MODE.
    - python main.py              -> tampil menu
    - python main.py --mode swap  -> langsung swap, tanpa menu (juga: perp)
    - tanpa terminal interaktif   -> pakai MODE dari settings.py
    """
    args = sys.argv[1:]
    if "--mode" in args:
        i = args.index("--mode")
        val = args[i + 1].lower() if i + 1 < len(args) else ""
        if val in ("swap", "perp", "future"):
            return "perp" if val == "future" else val
        print("❌ --mode harus 'swap' atau 'perp' (future).")
        sys.exit(1)

    default = getattr(cfg, "MODE", "swap")
    if not sys.stdin.isatty():
        return default

    sw = cfg.SWAP
    print("\n" + "═" * 56)
    print("  PILIH MODE TRADING")
    print("═" * 56)
    print(f"  [1] SWAP   — {sw['must_include']} (wajib) + acak: {', '.join(sw['pool'])}")
    print(f"               hold {sw['hold_seconds']/60:.0f} menit, market acak & nggak pernah sama 2x berturut")
    print(f"  [2] FUTURE — (perp) {', '.join(cfg.TRADING['markets'])}")
    print(f"               hold {cfg.DELAYS['hold_time_range'][0]//60}-{cfg.DELAYS['hold_time_range'][1]//60} menit, market acak")
    print("═" * 56)
    label = "1" if default == "swap" else "2"
    while True:
        ans = input(f"  Pilih 1 atau 2 [Enter = {label}]: ").strip().lower()
        if ans == "":
            return default
        if ans in ("1", "swap", "s"):
            return "swap"
        if ans in ("2", "future", "perp", "f", "p"):
            return "perp"
        print("  Input tidak dikenal, ketik 1 atau 2.")


# ─── MAIN ────────────────────────────────────────────────────────────────────

async def main():
    key_file = Path("user_data/private_key.txt")
    if not key_file.exists() or not key_file.read_text().strip():
        print("❌ File user_data/private_key.txt kosong atau tidak ada!")
        sys.exit(1)

    pk = key_file.read_text().strip()
    if not pk.startswith("0x"):
        pk = "0x" + pk

    cfg.MODE = choose_mode()
    log.info(f"Mode dipilih: {'SWAP' if cfg.MODE == 'swap' else 'FUTURE (perp)'}")

    Path("logs").mkdir(exist_ok=True)
    Path("user_data").mkdir(exist_ok=True)

    cookies = load_cookies_from_file()

    client = VariationalClient(
        eth_private_key = pk,
        jwt_token       = cookies["vr_token"],
        cf_clearance    = cookies["cf_clearance"],
        cfbm_cookie     = cookies["cf_bm"],
    )
    if cookies["vr_token"]:
        client.jwt_expires_at = datetime.now() + timedelta(days=7)

    state = BotState()
    state.leverage = cfg.BALANCE.get("leverage", 1)
    tg = None

    try:
        log.info(f"Wallet: {client.eth_address}")
        state.wallet_address = client.eth_address

        if not await ensure_authenticated_with_retry(client, max_attempts=5, wait_sec=30):
            log.error("Tidak bisa autentikasi ke Variational. Bot berhenti.")
            return

        if TelegramNotifier:
            async def _close_from_telegram():
                if not state.position:
                    return False
                state.force_close_requested = True
                ok = await close_position(client, state.position, tg=tg, state=state, reason="MANUAL")
                state.position = None
                return ok

            async def _live_pnl_for_telegram():
                if not state.position:
                    return None
                try:
                    return await get_live_pnl(client, state.position)
                except Exception:
                    return None

            tg = TelegramNotifier(
                bot_token         = cfg.TELEGRAM["bot_token"],
                chat_id           = cfg.TELEGRAM["chat_id"],
                state             = state,
                logger            = log,
                get_live_pnl_fn   = _live_pnl_for_telegram,
                close_position_fn = _close_from_telegram,
            )
            await tg.start()
            await tg.notify(
                f"🚀 <b>Variational Bot online</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"Wallet   : <code>{client.eth_address}</code>\n"
                f"Leverage : <code>x{state._lev()}</code>\n"
                f"TP / SL  : <code>{cfg.TRADING.get('take_profit_pct', 0)}% / {cfg.TRADING.get('stop_loss_pct', 0)}%</code>\n"
                f"Mode     : <code>{cfg.MODE.upper()}</code>\n"
                f"Market   : <code>{', '.join(([cfg.SWAP['must_include']] + cfg.SWAP['pool']) if cfg.MODE == 'swap' else cfg.TRADING['markets'])}</code>"
            )

        await farming_loop(client, state, tg=tg)

    except asyncio.CancelledError:
        pass
    except KeyboardInterrupt:
        pass
    finally:
        if tg:
            await tg.notify("⛔ Bot dihentikan.")
            await tg.stop()
        await client.close()
        log.info("Bot dihentikan.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⛔ Bot dihentikan. Sampai jumpa!")
        sys.exit(0)

"""
Telegram integration untuk Variational Bot
============================================
- Notifikasi otomatis: open/close posisi, alert PnL minus, error, daily report
- Kontrol dari Telegram: /status (+ tombol Close Now), /pause, /resume,
  /balance, /stats, /killswitch

Bot ini nempel ke loop trading yang sudah ada (main.py) lewat objek `state`
(modules/core/state.py) dan callback `get_live_quote_fn` / `close_position_fn`.
Loop trading utama TIDAK diubah logikanya sama sekali oleh modul ini.
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, ContextTypes
)


class TelegramNotifier:
    def __init__(self, bot_token: str, chat_id: str, state, logger,
                 get_live_pnl_fn=None, close_position_fn=None):
        """
        state              : instance BotState (modules/core/state.py)
        get_live_pnl_fn    : async fn() -> dict | None
                              hasil: {"market","side","entry","mark","pnl","pnl_pct"}
        close_position_fn  : async fn() -> bool  (force-close posisi yang lagi aktif)
        """
        self.chat_id = str(chat_id)
        self.state = state
        self.log = logger
        self.get_live_pnl_fn = get_live_pnl_fn
        self.close_position_fn = close_position_fn

        self.app: Application = Application.builder().token(bot_token).build()
        self.app.add_handler(CommandHandler("start", self._cmd_help))
        self.app.add_handler(CommandHandler("help", self._cmd_help))
        self.app.add_handler(CommandHandler("status", self._cmd_status))
        self.app.add_handler(CommandHandler("balance", self._cmd_balance))
        self.app.add_handler(CommandHandler("stats", self._cmd_stats))
        self.app.add_handler(CommandHandler("pause", self._cmd_pause))
        self.app.add_handler(CommandHandler("resume", self._cmd_resume))
        self.app.add_handler(CommandHandler("killswitch", self._cmd_killswitch))
        self.app.add_handler(CallbackQueryHandler(self._on_button))

    # ─── lifecycle ──────────────────────────────────────────────────────────

    async def start(self):
        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling(drop_pending_updates=True)
        self.log.success("Telegram bot aktif, siap terima command.")

    async def stop(self):
        try:
            await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()
        except Exception:
            pass

    # ─── kirim notif (dipanggil dari main.py) ──────────────────────────────

    async def notify(self, text: str):
        if not self.chat_id:
            return
        try:
            await self.app.bot.send_message(chat_id=self.chat_id, text=text, parse_mode="HTML")
        except Exception as e:
            self.log.warning(f"Gagal kirim notif Telegram: {e}")

    def _wallet_short(self) -> str:
        w = getattr(self.state, "wallet_address", "") or ""
        return f"{w[:6]}...{w[-4:]}" if len(w) > 10 else w

    def _lev(self) -> str:
        lev = getattr(self.state, "leverage", 1) or 1
        return str(int(lev)) if float(lev).is_integer() else f"{lev:g}"

    async def notify_open(self, market, side, entry_price, size_usd):
        emoji = "🟢" if side == "LONG" else "🔴"
        lev = float(getattr(self.state, "leverage", 1) or 1)
        margin = size_usd / lev if lev else size_usd
        await self.notify(
            f"{emoji} <b>OPEN {side} · {market}</b>  <b>x{self._lev()}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"Entry    : <code>${entry_price:,.4f}</code>\n"
            f"Size     : <code>${size_usd:,.2f}</code>\n"
            f"Leverage : <code>x{self._lev()}</code>\n"
            f"Margin   : <code>${margin:,.2f}</code>\n"
            f"Wallet   : <code>{self._wallet_short()}</code>"
        )

    async def notify_close(self, market, side, close_price, pnl, hold_sec, reason="TIME"):
        emoji = "✅" if pnl >= 0 else "🔴"
        reason_label = {
            "TP": "🎯 Take Profit",
            "SL": "🛑 Stop Loss",
            "TIME": "⏱ Batas Waktu",
            "MANUAL": "👆 Manual (Telegram)",
        }.get(reason, reason)
        await self.notify(
            f"{emoji} <b>CLOSE {side} · {market}</b>  <b>x{self._lev()}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"Harga    : <code>${close_price:,.4f}</code>\n"
            f"PnL      : <code>${pnl:+,.2f}</code>\n"
            f"Leverage : <code>x{self._lev()}</code>\n"
            f"Held     : <code>{hold_sec:.0f}s</code>\n"
            f"Alasan   : {reason_label}"
        )

    async def notify_pnl_alert(self, market, side, pnl_pct):
        await self.notify(
            f"⚠️ <b>PnL WARNING · {side} {market}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"PnL: <code>{pnl_pct:+.1f}%</code>\n"
            f"Cek /status kalau mau close manual."
        )

    async def notify_error(self, text: str):
        await self.notify(f"❌ <b>ERROR</b>\n{text}")

    async def notify_report(self):
        await self.notify(
            f"📊 <b>SESSION REPORT — VARIATIONAL BOT</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"<pre>{self.state.stats_text()}</pre>"
        )

    # ─── commands ───────────────────────────────────────────────────────────

    async def _cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "🤖 <b>Variational Bot</b> — Command:\n"
            "/status  - posisi aktif + PnL live\n"
            "/balance - cek saldo\n"
            "/stats   - statistik session\n"
            "/pause   - jeda loop farming\n"
            "/resume  - lanjutkan loop\n"
            "/killswitch - stop total & close posisi darurat",
            parse_mode="HTML",
        )

    async def _cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        pos = self.state.position
        if not pos:
            await update.message.reply_text("Nggak ada posisi yang lagi kebuka saat ini.")
            return

        text = (
            f"📍 <b>{pos['side']} · {pos['market']}</b>  <b>x{self._lev()}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"Entry : <code>${pos['entry_price']:,.4f}</code>"
        )
        if self.get_live_pnl_fn:
            live = await self.get_live_pnl_fn()
            if live:
                pnl_emoji = "✅" if live["pnl"] >= 0 else "🔴"
                text = (
                    f"📍 <b>{live['side']} · {live['market']}</b>  <b>x{self._lev()}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"Entry : <code>${live['entry']:,.4f}</code>\n"
                    f"Now   : <code>${live['mark']:,.4f}</code>\n"
                    f"PnL   : {pnl_emoji} <code>${live['pnl']:+,.2f} ({live['pnl_pct']:+.2f}%)</code>"
                )

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("🔴 Close Now", callback_data="close_now")
        ]])
        await update.message.reply_text(text, reply_markup=keyboard, parse_mode="HTML")

    async def _cmd_balance(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(f"💰 <b>Saldo:</b> <code>${self.state.balance:,.2f}</code>", parse_mode="HTML")

    async def _cmd_stats(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            f"📊 <b>Stats session</b>\n━━━━━━━━━━━━━━━━━━━━\n<pre>{self.state.stats_text()}</pre>",
            parse_mode="HTML",
        )

    async def _cmd_pause(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self.state.paused = True
        await update.message.reply_text("⏸️ Loop farming dijeda. Posisi aktif (kalau ada) tetap jalan normal. Ketik /resume buat lanjut.")

    async def _cmd_resume(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self.state.paused = False
        await update.message.reply_text("▶️ Loop farming dilanjutkan.")

    async def _cmd_killswitch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self.state.killswitch = True
        await update.message.reply_text("🛑 Killswitch diaktifkan. Posisi aktif akan ditutup paksa dan bot berhenti total.")

    async def _on_button(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        if query.data == "close_now":
            if not self.state.position:
                await query.edit_message_text("Nggak ada posisi aktif untuk ditutup.")
                return
            if not self.close_position_fn:
                await query.edit_message_text("Fungsi close belum terpasang.")
                return
            await query.edit_message_text("⏳ Menutup posisi...")
            ok = await self.close_position_fn()
            if ok:
                await query.message.reply_text("✅ Posisi berhasil ditutup manual dari Telegram.")
            else:
                await query.message.reply_text("❌ Gagal menutup posisi, cek log.")

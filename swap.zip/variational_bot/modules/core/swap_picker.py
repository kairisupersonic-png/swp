"""
SwapPicker — pilih market swap secara acak, tapi market wajib (XAU) selalu ada.

Cara kerja: bot bikin "ronde". Tiap ronde isinya:
    [market wajib] + N market acak dari pool   -> diacak urutannya
Jadi XAU dijamin muncul minimal 1x tiap ronde (N+1 posisi), market lain acak,
dan market yang sama TIDAK pernah dipakai dua kali berturut-turut.
"""
import random


class SwapPicker:
    def __init__(self, must: str, pool: list, others_per_round: int = 2, rng=None):
        self.must = must
        self.others = [m for m in pool if m != must]
        self.k = max(0, min(others_per_round, len(self.others)))
        self.rng = rng or random
        self.queue: list = []
        self.last = None

    def _new_round(self):
        rnd = [self.must] + self.rng.sample(self.others, self.k)
        self.rng.shuffle(rnd)
        # hindari market yang sama persis dengan posisi terakhir
        if len(rnd) > 1 and rnd[0] == self.last:
            j = next(i for i, m in enumerate(rnd) if m != self.last)
            rnd[0], rnd[j] = rnd[j], rnd[0]
        self.queue = rnd

    def next(self) -> str:
        if not self.queue:
            self._new_round()
        m = self.queue.pop(0)
        self.last = m
        return m

    def requeue(self, market: str):
        """Dipanggil kalau open gagal (mis. market lagi tutup): coba lagi nanti, setelah market lain."""
        self.queue.append(market)

    def describe(self) -> str:
        return f"{self.must} (wajib) + {self.k} acak dari {', '.join(self.others)}"

"""
BotState — state yang dipakai bersama antara farming_loop() dan Telegram bot.
Bukan cuma nyimpen data, tapi juga jadi "jembatan" perintah dari Telegram
ke loop trading (pause/resume/force-close/killswitch).
"""
import time


class BotState:
    def __init__(self):
        # Posisi yang lagi kebuka sekarang (None kalau nggak ada)
        self.position: dict | None = None

        # Kontrol loop
        self.paused: bool = False
        self.killswitch: bool = False
        self.force_close_requested: bool = False

        # Info umum
        self.wallet_address: str = ""
        self.balance: float = 0.0
        self.leverage: float = 1

        # Statistik sejak bot start
        self.start_time: float = time.time()
        self.total_volume: float = 0.0
        self.total_pnl: float = 0.0
        self.trade_count: int = 0
        self.win_count: int = 0
        self.loss_count: int = 0

    def record_close(self, pnl: float, size_usd: float):
        self.total_pnl += pnl
        self.total_volume += size_usd * 2
        self.trade_count += 1
        if pnl >= 0:
            self.win_count += 1
        else:
            self.loss_count += 1

    def _lev(self) -> str:
        lev = self.leverage
        return str(int(lev)) if float(lev).is_integer() else f"{lev:g}"

    def stats_text(self) -> str:
        uptime_min = (time.time() - self.start_time) / 60
        return (
            f"Saldo        : ${self.balance:,.2f}\n"
            f"Leverage     : x{self._lev()}\n"
            f"Total PnL    : ${self.total_pnl:+,.2f}\n"
            f"Total Volume : ${self.total_volume:,.2f}\n"
            f"Total Trade  : {self.trade_count} (W:{self.win_count} / L:{self.loss_count})\n"
            f"Uptime       : {uptime_min:.0f} menit"
        )

# 🤖 Variational Auto Trading Bot

Auto trading bot untuk Variational Protocol.
Ukuran posisi **otomatis menyesuaikan saldo** akun kamu.

## ⚙️ Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Isi private key
Buat file `user_data/private_key.txt`, isi dengan private key wallet:
```
0xABC123...private_key_kamu...
```

### 3. Deposit USDC ke Variational
- Buka https://omni.variational.io
- Connect wallet → Deposit USDC
- Bot akan baca saldo ini secara otomatis

### 4. (Opsional) Setup Telegram
1. Bikin bot lewat [@BotFather](https://t.me/BotFather), simpan **BOT_TOKEN**-nya
2. Cek **chat_id** kamu lewat [@userinfobot](https://t.me/userinfobot)
3. Set environment variable (atau isi langsung di `settings.py` -> `TELEGRAM`):
```bash
export TELEGRAM_BOT_TOKEN="123456:ABC-your-token"
export TELEGRAM_CHAT_ID="123456789"
```
4. Command yang bisa dipakai di Telegram: `/status` (+ tombol Close Now), `/balance`, `/stats`, `/pause`, `/resume`, `/killswitch`

### 5. Jalankan
```bash
python main.py
```

---

## 📊 Cara kerja auto-sizing

| Saldo USDC | Reserve 10% | Usable | Trade Size (20%) |
|-----------|------------|--------|-----------------|
| $100      | $10        | $90    | $18 → min $10   |
| $500      | $50        | $450   | $90             |
| $1,000    | $100       | $900   | $180            |
| $5,000    | $500       | $4,500 | $900            |

Bot refresh saldo setiap 5 cycle dan adjust ukuran trade otomatis.

---

## ⚙️ Konfigurasi (`settings.py`)

```python
BALANCE = {
    "usage_pct": 0.20,      # Pakai 20% saldo per trade
    "reserve_pct": 0.10,    # Sisakan 10% tidak disentuh
    "min_size_usd": 10,     # Minimum $10 per trade
    "max_size_usd": 500,    # Maksimum $500 per trade
}
DELAYS = {
    "hold_time_range": [30, 120],   # Tahan posisi 30-120 detik
    "between_cycles": [10, 30],     # Jeda 10-30 detik antar trade
}
```

---

## ⚠️ Disclaimer
- Simpan private key hanya di laptop pribadi
- Trading crypto selalu mengandung risiko
- Bot ini untuk farming volume, bukan profit guaranteed

---

## 🔁 Mode SWAP (acak, XAU wajib)

`python main.py` → pilih `1` (SWAP) atau `2` (FUTURE/perp). Di mode SWAP bot:
1. Bikin "ronde": **XAU** + N market acak dari `SWAP["pool"]` (default US100, US500, XAG), urutan diacak
2. Buka posisi → tahan **30 menit** → close → posisi berikutnya di market lain
3. XAU dijamin muncul minimal sekali per ronde; market yang sama tidak pernah dipakai 2x berturut-turut
4. Kalau market lagi tutup / order gagal, market itu ditaruh di belakang antrian dan bot coba market lain dulu

**Wajib sebelum jalan:** `python probe_swap.py` untuk memastikan `instrument_type` / nama underlying swap,
isi hasilnya di `SWAP` (`settings.py`). Leverage max beda per market (XAU/US100/US500/XAG 10x, COCOA/VXI/USOIL 5x),
jadi `BALANCE["leverage"]` jangan lebih tinggi dari itu.

### Pilih mode saat start
`python main.py` menampilkan menu: `1` = SWAP, `2` = FUTURE (perp). Enter = pakai `MODE` di settings.py.
Lewati menu: `python main.py --mode swap` atau `python main.py --mode perp`.

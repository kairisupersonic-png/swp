"""
probe_swap.py — cari format instrument SWAP yang diterima API Variational.
Hanya minta INDICATIVE QUOTE (informasi harga). TIDAK ada order yang dieksekusi.

Jalankan:  python probe_swap.py
Hasilnya: kombinasi (instrument_type, underlying) yang berhasil -> isi ke settings.SWAP
Kalau semua gagal: buka omni.variational.io, DevTools (F12) > Network, klik XAU swap,
cari request 'quotes/indicative', copy field "instrument" dari Payload.
"""
import asyncio, itertools
from pathlib import Path
from datetime import datetime, timedelta

from main import load_cookies_from_file, ensure_authenticated
from modules.core.variational_client import VariationalClient

TYPES = ["swap", "swap_future", "linear_swap", "total_return_swap", "perpetual_swap"]
import settings as cfg
# XAU dicoba dengan beberapa kemungkinan nama; market lain pakai nama aslinya
UNDERLYINGS = ["XAU", "XAUS", "XAUP"] + [m for m in cfg.SWAP["pool"]]

async def main():
    pk = Path("user_data/private_key.txt").read_text().strip()
    ck = load_cookies_from_file()
    c = VariationalClient(pk if pk.startswith("0x") else "0x" + pk,
                          jwt_token=ck["vr_token"], cf_clearance=ck["cf_clearance"], cfbm_cookie=ck["cf_bm"])
    if ck["vr_token"]:
        c.jwt_expires_at = datetime.now() + timedelta(days=7)
    try:
        if not await ensure_authenticated(c):
            return
        for t, u in itertools.product(TYPES, UNDERLYINGS):
            try:
                q = await c.get_indicative_quote(u, 0.001, instrument_type=t)
                ok = bool(q.get("quote_id")) and float(q.get("mark_price", 0)) > 0
                print(("OK   " if ok else "FAIL ") + f"type={t:<18} underlying={u:<5} -> {str(q)[:140]}")
            except Exception as e:
                print(f"FAIL type={t:<18} underlying={u:<5} -> {str(e)[:100]}")
            await asyncio.sleep(1.5)
    finally:
        await c.close()

asyncio.run(main())
